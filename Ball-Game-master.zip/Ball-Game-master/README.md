# Ball-Game
JAVA Ball Game 

#Introduction
 
  The Game Consists of A Screen Divided Into Two Sections. Each section consists of two pairs of ball with each pair having same color.
  The Main Aim of the Game is to get the balls to the Section containing the color of similar to that of the ball. Each time you are able
  to pot the ball to it's respective section  the level increases with more balls in the screen...
  
  When the level increases the ball is increased of the section you lastly potted the ball.The game is totally based on the movement of the
  divider in the middle of screen it contains a small opening for the passing of ball from one side to another.
  
  
#System Requirements

An implementation of Java SE 7 or newer:

OpenJDK http://openjdk.java.net/install/ or Sun JDK http://www.oracle.com/technetwork/java/javase/downloads/ or IBM JDK http://www.ibm.com/developerworks/java/jdk/

OpenJDK http://openjdk.java.net/install/ or

Sun JDK http://www.oracle.com/technetwork/java/javase/downloads/ or

IBM JDK http://www.ibm.com/developerworks/java/jdk/

Hope , it will be easy to use the given Project.

Code4Fun....

Feel Free To Deliver Your Queries To My E-Mail
